package com.example.admin.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListNameAdapter extends BaseAdapter {


    OnViewClickListener mListenner;
    private Context mContext;

    private ArrayList<Product> mData = new ArrayList<>();

    public ListNameAdapter(Context context, ArrayList<Product> m,OnViewClickListener list) {
        mContext = context;
        mData = m;
        mListenner = list;
    }
    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.item_name, viewGroup, false);

        TextView txtName = (TextView) rowView.findViewById(R.id.txt_name);
        TextView txtPrice = (TextView) rowView.findViewById(R.id.txt_price);

        txtName.setText(mData.get(position).getName());
        txtPrice.setText(mData.get(position).getPrice()+"");

        Button btnEdit = (Button)rowView.findViewById(R.id.item_btnEdit) ;
        Button btnDelete = (Button)rowView.findViewById(R.id.item_btnDelete) ;
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListenner != null){
                    mListenner.onEditClick(position);
                }
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mListenner != null){
                    mListenner.onDeleteClick(position);
                }
            }
        });

        return rowView;
    }

    public interface OnViewClickListener{
        void onEditClick(int pos);
        void onDeleteClick(int pos);
    }
}
