package com.example.admin.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ListNameAdapter.OnViewClickListener{
    Button btnAdd;
    EditText editName, editPrice, editQuantity;
    ListView mListView;
    ArrayList<Product> mData = new ArrayList<>();
    int position;
    ListNameAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editName = (EditText)findViewById(R.id.activity_editName);
        editPrice = (EditText)findViewById(R.id.activity_editPrice);
        editQuantity = (EditText)findViewById(R.id.activity_editQuantity);
        mListView = (ListView)findViewById(R.id.activity_Listview);
        btnAdd = (Button)findViewById(R.id.activity_btnAdd);



        adapter = new ListNameAdapter(this, mData,this);
        mListView.setAdapter(adapter);


        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editQuantity.getText().toString() != "" && editPrice.getText().toString() != "" && editName.getText().toString() != "") {
                    Product p = new Product(editName.getText().toString(),Double.parseDouble(editPrice.getText().toString()),Integer.parseInt(editQuantity.getText().toString()));
                    mData.add(p);
                    adapter.notifyDataSetChanged();
                }else {
                    System.out.print("KHoongh dc rong");
                }


            }
        });



    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 30){
            String strName = data.getStringExtra("name");
            String strPrice = data.getStringExtra("price");
            String strQuantity = data.getStringExtra("quantity");
            mData.get(position).setName(strName);
            mData.get(position).setPrice(Double.parseDouble(strPrice));
            mData.get(position).setQuantity(Integer.parseInt(strQuantity));
            adapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onEditClick(int pos) {
        this.position = pos;
        Intent intent = new Intent(MainActivity.this,EditActivity.class);
        intent.putExtra("name",mData.get(pos).getName());
        intent.putExtra("price",mData.get(pos).getPrice());
        intent.putExtra("quantity",mData.get(pos).getQuantity());
        startActivityForResult(intent,5);
    }

    @Override
    public void onDeleteClick(int pos) {
        AskOption(pos).show();
    }
    private AlertDialog AskOption(final int pos){
        AlertDialog myDeleteDialogBox = new AlertDialog.Builder(this)
                .setTitle("Box")
                .setMessage("Are you sure")
                .setIcon(null)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mData.remove( mData.get(pos));
                        adapter.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();
        return myDeleteDialogBox;
    }
}
