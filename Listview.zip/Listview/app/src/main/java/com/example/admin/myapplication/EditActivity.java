package com.example.admin.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class EditActivity extends Activity {
    EditText edit_txtName,edit_txtPrice,edit_txtQuantity;
    Button btnSave, btnCancel;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        edit_txtName = (EditText)findViewById(R.id.edit_editName);
        edit_txtPrice = (EditText)findViewById(R.id.edit_editPrice);
        edit_txtQuantity = (EditText)findViewById(R.id.edit_editQuantity);
        btnSave = (Button)findViewById(R.id.edit_btnSave);
        btnCancel = (Button)findViewById(R.id.edit_btnCancel);

        if (getIntent() != null){
            Log.e("asas",getIntent().getStringExtra("name"));
            edit_txtName.setText(getIntent().getStringExtra("name"));
            edit_txtPrice.setText(getIntent().getDoubleExtra("price",0)+"");
            edit_txtQuantity.setText(getIntent().getIntExtra("quantity",0)+"");
        }


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.putExtra("name",edit_txtName.getText().toString());
                intent.putExtra("price",edit_txtPrice.getText().toString());
                intent.putExtra("quantity",edit_txtQuantity.getText().toString());
                setResult(30,intent);
                finish();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
