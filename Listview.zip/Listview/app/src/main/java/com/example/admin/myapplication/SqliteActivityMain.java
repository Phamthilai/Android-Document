package com.example.admin.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class SqliteActivityMain extends Activity {

    EditText editName, editPrice, editQuantity;
    Button btnAdd,btnView;

    MyDatabase myDatabase = new MyDatabase(this,"",null,1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editName = (EditText)findViewById(R.id.activity_editName);
        editPrice = (EditText)findViewById(R.id.activity_editPrice);
        editQuantity = (EditText)findViewById(R.id.activity_editQuantity);

        btnAdd = (Button)findViewById(R.id.activity_btnAdd);
        btnView = (Button)findViewById(R.id.activity_btnView);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                Double price = Double.parseDouble(editPrice.getText().toString());
                Integer quantity = Integer.parseInt(editQuantity.getText().toString());
                myDatabase.insertProduct(name,price,quantity);
                editName.setText("");
                editPrice.setText("");
                editQuantity.setText("");
            }
        });
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<Product> list = myDatabase.getProduct();
                Log.e("Products","sdsd");
                for (int i = 0 ;i<list.size();i++){
                    Log.e("Products","name:"+list.get(i).getName()+" price:"+list.get(i).getPrice()+" quantity:"+list.get(i).getQuantity());
                }
            }
        });


    }
}
