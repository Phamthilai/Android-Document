package com.example.admin.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class MyDatabase extends SQLiteOpenHelper {
    private static String DATABASE_NAME ="shop.db";
    private String TABLE_NAME ="products";
    private String CREATE_TABLE ="create table products(name text, price real, quantity integer)";
    private String DELETE_TABLE = "drop table if exists products";

    public MyDatabase(Context context,String name,SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DELETE_TABLE);
        onCreate(db);
    }

    public void insertProduct(String name, double price, int quantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name",name);
        values.put("price",price);
        values.put("quantity",quantity);
        db.insert(TABLE_NAME,null,values);
    }

    public ArrayList<Product> getProduct(){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from products";
        Cursor cursor = db.rawQuery(sql,null);

        ArrayList<Product> productlists = new ArrayList<>();
        while (cursor.moveToNext()){
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            Double price = cursor.getDouble(cursor.getColumnIndexOrThrow("price"));
            Integer quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

            Product product = new Product(name,price,quantity);
            productlists.add(product);
        }
        return productlists;
    }

}
