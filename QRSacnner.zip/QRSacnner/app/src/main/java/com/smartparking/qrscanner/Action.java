package com.smartparking.qrscanner;

import android.content.Context;
import android.widget.Toast;

import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.SaveCallback;

public class Action {

    public void parseConnection(Context context) {
        Parse.initialize(new Parse.Configuration.Builder(context)
                .applicationId("n5k0cNPdmW1kLFInNlKdoGusTJ5WE9Gg6nL8uc3R")
                .clientKey("Wd81NWpxXIN2mES8tgPjmupI4dbOWBublRc2eyaN")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }
    public void saveHistoryUser(final Context context, String username){
        ParseObject history = new ParseObject("history");

        history.put("Address", "Đà Nẵng");
        history.put("totalMoney", "10.000");
        history.put("username", username);

        history.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {
                Toast.makeText(context, "Save result OK", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
